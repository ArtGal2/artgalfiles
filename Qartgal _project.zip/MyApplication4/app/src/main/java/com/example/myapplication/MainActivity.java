package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lobby);
        Button start_b = findViewById(R.id.button_start);
        Button level_choose_b = findViewById(R.id.to_level_menu_lob);
        Button feedback_b = findViewById(R.id.button_feedback);

        //Перевод на 1 уровень
        start_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,level_1_1.class));


            }
        });

        //переход на выбор уровня
        level_choose_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,levels_menu.class));


            }
        });

        //Перевод на экран с обратной связью
        feedback_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,Feedback.class));


            }
        });
    }

}

