package com.example.myapplication;

public class QestList {
    private String qestion ;
    private String ans_1,ans_2,ans_3,ans_4;
    public QestList(String qestion, String ans_1, String ans_2, String ans_3, String ans_4){
        this.qestion = qestion;
        this.ans_1 = ans_1;
        this.ans_2 = ans_2;
        this.ans_3 = ans_3;
        this.ans_4 = ans_4;
    }
    public String getQestion(){
        return qestion;
    }
    public String getAns_1(){
        return ans_1;
    }
    public String getAns_2(){
        return ans_2;
    }
    public String getAns_3(){
        return ans_3;
    }
    public String getAns_4(){
        return ans_4;
    }
}
