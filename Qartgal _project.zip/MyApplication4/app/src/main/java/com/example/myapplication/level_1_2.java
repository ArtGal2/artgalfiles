package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class level_1_2 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.level_1);

        Button back_button = findViewById(R.id.to_lob_lvl1);
        TextView qestion = findViewById(R.id.qestion_1);
        ProgressBar progress = findViewById(R.id.progress_lvl1);
        ProgressBar progress_r = findViewById(R.id.right_progress);
        Button ans_1 = findViewById(R.id.ans_1);
        Button ans_2 = findViewById(R.id.ans_2);
        Button ans_3 = findViewById(R.id.ans_3);
        Button ans_4 = findViewById(R.id.ans_4);
        Button next_lvl = findViewById(R.id.next_end);
        Button back_lobby = findViewById(R.id.back_end);
        TextView prog_procent = findViewById(R.id.right_ans);

        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(level_1_2.this,MainActivity.class));
                finish();
            }
        });
        ans_1.setVisibility(Button.INVISIBLE);
        ans_2.setVisibility(Button.INVISIBLE);
        ans_3.setVisibility(Button.INVISIBLE);
        ans_4.setVisibility(Button.INVISIBLE);
        progress.setVisibility(ProgressBar.INVISIBLE);
        prog_procent.setVisibility(TextView.INVISIBLE);
        progress_r.setVisibility(ProgressBar.INVISIBLE);
        back_button.setVisibility(Button.INVISIBLE);
        back_lobby.setVisibility(Button.VISIBLE);
        qestion.setText("Технические шоколадки... \n Ведутся работы...");
        back_lobby.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


    }

}

