package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class levels_menu extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.level_choose);

        Button back_button = findViewById(R.id.to_lob_lvl1);
        Button to_lvl_1 = findViewById(R.id.lvl_1);
        Button to_lvl_2 = findViewById(R.id.lvl_2);
        Button to_lvl_3 = findViewById(R.id.lvl_3);
        Button to_lvl_4 = findViewById(R.id.lvl_4);
        Button to_lvl_1_2 = findViewById(R.id.lvl_1_2);
        Button to_lvl_2_2 = findViewById(R.id.lvl_2_2);
        Button to_lvl_3_2 = findViewById(R.id.lvl_3_2);
        Button to_lvl_4_2 = findViewById(R.id.lvl_4_2);
        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        to_lvl_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(levels_menu.this,level_1_1.class));
                finish();
            }
        });
        to_lvl_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(levels_menu.this,level_1_2.class));
                finish();
            }
        });
        to_lvl_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(levels_menu.this,level_1_2.class));
                finish();
            }
        });
        to_lvl_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(levels_menu.this,level_1_2.class));
                finish();
            }
        });
        to_lvl_1_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(levels_menu.this,level_2_1.class));
                finish();
            }
        });
        to_lvl_2_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(levels_menu.this,level_1_2.class));
                finish();
            }
        });
        to_lvl_3_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(levels_menu.this,level_1_2.class));
                finish();
            }
        });
        to_lvl_4_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(levels_menu.this,level_1_2.class));
                finish();
            }
        });

    }

}
